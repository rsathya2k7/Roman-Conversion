import { NgModule } from "@angular/core";
import { Routes, RouterModule } from "@angular/router";
import { HomeComponent } from "./components/home/home.component";
import { AboutComponent } from "./components/about/about.component";
import { ContactComponent } from "./components/contact/contact.component";
import { AddEventComponent } from "./components/add-event/add-event.component";
var routes: Routes = [
 {
     path : '',
     component : HomeComponent
 },

 {
     path : 'about',
     component : AboutComponent
 },

 {
    path : 'contact',
    component : ContactComponent
},
{
  path :'newevent',
  component:AddEventComponent
}


]
@NgModule({
  imports:[
    //importing empty router module and adding routed to it    
    RouterModule.forRoot(routes)
  ],
  exports:[
    //exporting the updated router module to the mainmodule
    RouterModule
  ]
})

export class AppRoutingModule{

}
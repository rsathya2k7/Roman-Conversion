///we can also create constructor to set default values
export class EventInfo {

    public id : number;

    public title: string;

    public trainer: string;

    public eventDate: Date;

    public startTime: string;

    public endTime: string;

    public location: string;
    
    public courseFee: number;
    
    public offerValue: number;

    //title:string="a" default parameter or optional title?:string
    constructor(title?:string,trainer?:string,datestart?:Date,stTime?:string,endtime?:string,location?:string,coursefee?:number,offerValue?:number)
    {
        this.title = title;
        this.trainer = trainer;
        this.eventDate = datestart;
        this.startTime = stTime;
        this.endTime = endtime;
        this.location = location;
        this.courseFee = coursefee;
        this.offerValue = offerValue;                    
    }
}
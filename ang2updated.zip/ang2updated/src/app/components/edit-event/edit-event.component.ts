import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from "@angular/router";
import { EventDataService } from "../../services/event-data.service";
import { FormBuilder, FormGroup, Validators, FormControl } from "@angular/forms";

@Component({
  selector: 'app-edit-event',
  templateUrl: './edit-event.component.html',
  styleUrls: ['./edit-event.component.css']
})
export class EditEventComponent implements OnInit {

  private eventForm : FormGroup;
  constructor(private route:ActivatedRoute, 
    private eventDataSvc:EventDataService,
    private formBuilder : FormBuilder) { 
      this.eventForm = this.formBuilder.group(
        {
             id :[0,Validators.required],
             title:["",Validators.compose([Validators.required,Validators.minLength(10)])],
             trainer:["",Validators.compose([Validators.required,Validators.minLength(3)])],
             eventDate:["",Validators.required],
             location:["",Validators.required],
             startTime:["",Validators.required],
             endTime:["",Validators.required],
             courseFee:["",Validators.required],
             offerValue:new FormControl("",Validators.required)
   
        });

    } // injected a serivce ActivatedRoute for getting the current route info, passed parameter in route
  

  ngOnInit() {
    ///console.log(this.route.snapshot.params["id"]); //sync method 

    ///one more method both are same
   //this.route.params.subscribe(p=>console.log("id is" +p["id"])); //async method

   let id = this.route.snapshot.params["id"];

   //this.eventForm = new FormGroup([

   //]); // this method uses formgroup

  
   this.eventDataSvc.getEventById(id)
   .subscribe(
     data=>{
      this.eventForm = this.formBuilder.group(
        {
             id :[id,Validators.required],
             title:[data.title,Validators.compose([Validators.required,Validators.minLength(10)])],
             trainer:[data.trainer,Validators.compose([Validators.required,Validators.minLength(3)])],
             eventDate:[data.eventDate,Validators.required],
             location:[data.location,Validators.required],
             startTime:[data.startTime,Validators.required],
             endTime:[data.endTime,Validators.required],
             courseFee:[data.courseFee,Validators.required],
             offerValue:new FormControl(data.offerValue,Validators.required)
   
        });
     },
     err=>console.log("error")
   )
  
  }

}

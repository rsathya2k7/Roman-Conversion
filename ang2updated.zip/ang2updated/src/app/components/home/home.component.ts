import { Component, OnInit } from '@angular/core';
import { EventInfo } from "../../models/event-info";
import { EventDataService } from "../../services/event-data.service";
//import { EventDataService } from "../../services/event-data.service";

@Component({
	selector: 'home', //we can change the  name here this is being referred as tag in html
	templateUrl: './home.component.html',
	//template : `<h3>template testing</h3>`, // template is used to give inline html with back quote
	styleUrls: ['./home.component.css'],
	//styles :[`a{color :red}'] // for inlne styles use Stlyes
	providers :[EventDataService] // we can also register service at component level or globally in app.module.ts
})
export class HomeComponent implements OnInit { // OnDestroy interface

	private events: EventInfo[];
	private eventDataSvc: EventDataService;

	constructor(svc: EventDataService) {
		this.eventDataSvc = svc; /// declaring a local variable to member variable so it cab accessed anywhere
	}

	ngOnInit() {

		this.eventDataSvc.getEvents()
			.subscribe(
			data => this.events = data,
			err => console.log("error:", err)
			)
	}
}

    //or we can simplify this decalration  using type script
    //constructor(private eventDataSvc :EventDataService){   //directly declare the member variable with private keyword here thsi is only in Type script    
  //} 


   //ngOnInit()
    //{
    //  this.events = this.eventDataSvc.getEvents();
  //}             

 // ngOnDestroy also avaiable similar to destructor
     // if you are taking any binded value from any UI then user this nginit or else u can put in constructor

 //constructor() {  

    ///Hard coded without gettign from service directly writing in component
    //this.events=[
        //new EventInfo("Advanced angular 2","Sara",new Date("2017/9/9"),"10 AM","01:PM","Chennai",4500,3000), 
        //new EventInfo("React JS","Prabha",new Date("2017/9/19"),"11 AM","01:PM","Pune",5000,3400),
        //new EventInfo("SharePoint","Karan",new Date("2017/9/29"),"10:30 AM","01:PM","Delhi", 2000, 2000),     
       /// new EventInfo(), // also you can empty constructor but only one constructor in js so we are usind default or optional parameters.
      //];
    // constructor execute before binding
  // life cycle event hook , when the component is initialised in angular // some code need to be executed after binding
